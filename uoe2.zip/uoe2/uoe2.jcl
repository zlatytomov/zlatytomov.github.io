<?xml version="1.0" encoding="ISO-8859-1"?>

<hotpot-jcloze-file>
<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:dc="http://purl.org/dc/elements/1.1/">
  <rdf:Description rdf:about="">
    <dc:creator>zlaty tomov</dc:creator>
    <dc:title>Use Of English II</dc:title>
  </rdf:Description>
</rdf:RDF><version>7</version>

<data>
<title>Use Of English II</title>

<timer><seconds>60</seconds><include-timer>0</include-timer></timer>

<reading>
<include-reading>0</include-reading>
<reading-title></reading-title>
<reading-text></reading-text>

</reading>

<gap-fill>&amp;#x003C;b&amp;#x003E;I Mltiple choice &amp;#x003C;/b&amp;#x003E;
&amp;#x003C;i&amp;#x003E;For questions 1-9, read the text below and decide which answer (A, B, C or D) best fits each gap.&amp;#x003C;/i&amp;#x003E;

Old skills: new products
If ancient skills which have been (1) <question-record><question></question><answer><text>A</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> down from generation to generation are going to survive, then we must find new uses for them. A good example is the cloth (2) <question-record><question></question><answer><text>C</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> as Harris tweed, which is produced on an island off the northwest coast of Scotland. A few years ago, there was only one full-time weaver of the cloth left on the island. It was all that (3) <question-record><question></question><answer><text>A</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> of an industry that once employed a large (4) <question-record><question></question><answer><text>B</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> of local people.
But local producers are now providing material for use in a (5) <question-record><question></question><answer><text>A</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> of fashionable handbags, hats and furnishings. This (6) <question-record><question></question><answer><text>B</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> in the fortunes of the industry all started way (7) <question-record><question></question><answer><text>C</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> in 2004, when a sample of Harris tweed was sent to Nike, the sportswear manufacturer. The company decided to use the material on a trainer called &amp;#x2018;The Terminator&amp;#x2019; to demonstrate how (8) <question-record><question></question><answer><text>A</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> a traditional material can be incorporated into a modern product. This (9) <question-record><question></question><answer><text>D</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> to a large order for cloth, which involved lots of people on the island rediscovering the ancient skill of weaving.

1   A   passed           B   brought         C   carried          D   taken
2   A   seen                B   referred         C   known          D   regarded
3   A   remained       B   recalled          C   resumed      D   repeated
4   A   extent             B   number         C   degree          D   amount
5   A   range              B   choice            C   mixture        D   pick
6   A   increase                B   change           C   switch           D   move
7   A   ago                 B   past                C   back              D   since
8   A   effectively     B   especially       C   actually        D   certainly
9   A   followed        B   resulted         C   caused         D   led

&amp;#x003C;b&amp;#x003E;II Word formation&amp;#x003C;/b&amp;#x003E;
&amp;#x003C;i&amp;#x003E;For questions 1-9, read the text below. Use the word given in capitals to form a word that fits in the gap.&amp;#x003C;/i&amp;#x003E;

Rafting on the Zambezi river

Victoria Falls on the Zambezi river in Africa is one of the most (1) <question-record><question></question><answer><text>spectacular</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (SPECTACLE) sights in the world. It is also an (2) <question-record><question></question><answer><text>incredible</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (CREDIBLE) place for water sports. The translation of the local Zambian name for the falls is &amp;#x2018;the smoke that thunders&amp;#x2019; and it&amp;#x2019;s a pretty good (3) <question-record><question></question><answer><text>description</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (DESCRIBE). On arrival, it&amp;#x2019;s the noise that makes the greatest (4) <question-record><question></question><answer><text>impression</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (IMPRESS) on you as the water drops 108 metres in a waterfall that is nearly two kilometres wide. The (5) <question-record><question></question><answer><text>surrounding</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (SURROUND) landscape is also awesome, and well worth a visit.
You can&amp;#x2019;t go white-water rafting over the falls themselves, but the rapids (6) <question-record><question></question><answer><text>farther</text><feedback></feedback><correct>1</correct></answer><answer><text>further</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (FAR) down the Zambezi river provide a very exciting location. Although the rapids are given grades five and six on the sports (7) <question-record><question></question><answer><text>difficulty</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (DIFFICULT) scale, there are places where relative (8) <question-record><question></question><answer><text>beginners</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (BEGIN) can have a go, as long as they are accompanied by experienced operators. These people guide you through the rapids and ensure that you don&amp;#x2019;t stray into the more (9) <question-record><question></question><answer><text>dangerous</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> (DANGER) sections by mistake.

&amp;#x003C;b&amp;#x003E;III Open close&amp;#x003C;/b&amp;#x003E;
&amp;#x003C;i&amp;#x003E;For questions 1-9, read the text below and think of the word which best fits the gap. Use only one word in each gap.&amp;#x003C;/i&amp;#x003E;

The UK is home to half the world&amp;#x2019;s population of grey seals and there (1) <question-record><question></question><answer><text>are</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> many local boat trips offering sightseeing tours out to the islands and sandbanks (2) <question-record><question></question><answer><text>where</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> the animals are most regularly found.
But if you really want to get close (3) <question-record><question></question><answer><text>to</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> the seals and understand something about their way of life, then you need to go on an underwater seal-watching trip. On these trips, you have the chance to go over the side of the boat and, equipped (4) <question-record><question></question><answer><text>with</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> a wetsuit, mask and snorkel, spend time in the water alongside the animals.
Seals are extremely inquisitive creatures and, once you&amp;#x2019;re in the water, they will swim past you trying to figure (5) <question-record><question></question><answer><text>out</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> who you are and (6) <question-record><question></question><answer><text>what</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> you&amp;#x2019;re doing there. (7) <question-record><question></question><answer><text>Although</text><feedback></feedback><correct>1</correct></answer><answer><text>though</text><feedback></feedback><correct>1</correct></answer><answer><text>while</text><feedback></feedback><correct>1</correct></answer><answer><text>whilst</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> they can appear shy at first, seals soon (8) <question-record><question></question><answer><text>get</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> used to you being in the water, and will come and play around you. Young pups especially like to (9) <question-record><question></question><answer><text>make</text><feedback></feedback><correct>1</correct></answer><answer><text>have</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> contact with divers, and often use their teeth, gently biting masks, fins and cameras out of curiosity. It can be a thrilling experience.

&amp;#x003C;b&amp;#x003E;IV Key word transformations&amp;#x003C;/b&amp;#x003E;
&amp;#x003C;i&amp;#x003E;Complete the sentence so that it has a similar meaning. &amp;#x003C;u&amp;#x003E;Do not change the word given&amp;#x003C;/u&amp;#x003E;. You must use between two and five words, including the word given.&amp;#x003C;/i&amp;#x003E;

1. How much do these leather shoes cost?
&amp;#x003C;b&amp;#x003E;price&amp;#x003C;/b&amp;#x003E;
What <question-record><question></question><answer><text>is the price of these</text><feedback></feedback><correct>1</correct></answer><answer><text>&apos;s the price of these</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> leather shoes?

2. It&apos;s not important if you come to work today or not.
&amp;#x003C;b&amp;#x003E;matter&amp;#x003C;/b&amp;#x003E;
It <question-record><question></question><answer><text>does not matter if</text><feedback></feedback><correct>1</correct></answer><answer><text>doesn&apos;t matter if</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> you come to work today or not.

3. Parking is prohibited in all areas of the business park.
&amp;#x003C;b&amp;#x003E;anywhere&amp;#x003C;/b&amp;#x003E;
You cannot <question-record><question></question><answer><text>park anywhere in</text><feedback></feedback><correct>1</correct></answer><answer><text>park anywhere in</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> the business park.

4. Mark&apos;s biggest problem is that he often ignores what I say in class.
&amp;#x003C;b&amp;#x003E;pay&amp;#x003C;/b&amp;#x003E;
His biggest problem is that he <question-record><question></question><answer><text>does not pay attention</text><feedback></feedback><correct>1</correct></answer><answer><text>does not pay any attention</text><feedback></feedback><correct>1</correct></answer><answer><text>doesn&apos;t pay attention</text><feedback></feedback><correct>1</correct></answer><answer><text>doesn&apos;t pay any attention</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> to what I say in class.

5. Your sister said she had told you everything.
&amp;#x003C;b&amp;#x003E;admitted&amp;#x003C;/b&amp;#x003E;
Your sister <question-record><question></question><answer><text>admitted telling you</text><feedback></feedback><correct>1</correct></answer><answer><text>admitted having told you</text><feedback></feedback><correct>1</correct></answer><answer><text>admitted she had told you</text><feedback></feedback><correct>1</correct></answer><answer><text>admitted that she had told you</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> everything.

6. If we light the fire, the rescuers will see us.
&amp;#x003C;b&amp;#x003E;be&amp;#x003C;/b&amp;#x003E;
We <question-record><question></question><answer><text>will be seen by the</text><feedback></feedback><correct>1</correct></answer><answer><text>&apos;ll be seen by the</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> rescuers if we light the fire.

7. For us to win this match now would be impossible.
&amp;#x003C;b&amp;#x003E;hope&amp;#x003C;/b&amp;#x003E;
There is no <question-record><question></question><answer><text>hope of winning</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> this match now.

8. Don&apos;t tell anyone this information
&amp;#x003C;b&amp;#x003E;keep&amp;#x003C;/b&amp;#x003E; 
You must <question-record><question></question><answer><text>keep this information to</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> yourself.

&amp;#x003C;b&amp;#x003E;V Reading&amp;#x003C;/b&amp;#x003E;
&amp;#x003C;i&amp;#x003E;You are going to read an article about a language. Six sentences have been removed from the article.
Choose from the sentences A-G the one which fits each gap (1-6). There is one extra sentence which you do not need to use.&amp;#x003C;/i&amp;#x003E;

A   I felt a sudden desire to learn that one too.
B   It was slow because I had no one to talk to.
C   Yag&amp;#x00E1;n is quite different, however, because it has more vocabulary.
D   This meant that I was able to start learning words, verbs and expressions.
E   This was good because I didn&amp;#x2019;t want to be the only one.
F   These turned out to be rather hard for me to pronounce, however.
G   The trip seemed the best way to find out about my roots.

I come from Chile and I&amp;#x2019;ve always been interested in my country&amp;#x2019;s history and culture. It all started when I was about eight and I started to learn about the country&amp;#x2019;s indigenous inhabitants. When I first found out about the native people of Patagonia, in the far south, I had no idea that my mother&amp;#x2019;s family was from there and that her grandfather had been a Selk&amp;#x2019;nam. The last speaker of Selk&amp;#x2019;nam died in 1974. I really wanted to learn Selk&amp;#x2019;nam, so relatives on my father&amp;#x2019;s side who live in Punta Arenas, the southernmost town in mainland Chile, sent me dictionaries. (1) <question-record><question></question><answer><text>D</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> But I had no idea what these sounded like.
Then, when I was about eleven, I saw a television programme about the Yag&amp;#x00E1;n people who lived on the island of Tierra del Fuego, the southernmost tip of South America. The programme interviewed two sisters, Cristina and Ursula Calder&amp;#x00F3;n, and said they were the only two speakers of their language left. (2) <question-record><question></question><answer><text>A</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> Only later did I discover that the two languages are quite different; that the two peoples couldn&amp;#x2019;t communicate with each other.
One day, my mother told me that although she was born in the capital, Santiago, her grandfather was a Selk&amp;#x2019;nam from the north of Tierra del Fuego. Nobody had ever told me anything about this before. When I asked why, she said that when she was young she had been teased for looking different, and so she had just kept quiet about it.
When I was thirteen, I went to the south for the first time on my own to meet Cristina Calder&amp;#x00F3;n. (3) <question-record><question></question><answer><text>G</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> I discovered that there used to be four thousand Selk&amp;#x2019;nam in Tierra del Fuego. They were hunters of wild cats and foxes. The Yag&amp;#x00E1;n lived further south and travelled by canoe all the way down to Cape Horn, but the Selk&amp;#x2019;nam moved on foot.
Settlers from the north arrived in the nineteenth century and introduced diseases like measles and typhoid, which affected the local people very badly. Now, there&amp;#x2019;s no way back. I got hold of some recordings of a Selk&amp;#x2019;nam shaman from the 1960s and started to study them. (4) <question-record><question></question><answer><text>B</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> Gradually, however, I began to understand how the words sounded and began to reproduce them.
The Selk&amp;#x2019;nam express themselves using lots of prefixes and suffixes, and the sounds are guttural, nasal and tonal. (5) <question-record><question></question><answer><text>C</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> For example, it has lots of different words for the weather. The hardest thing in Selk&amp;#x2019;nam, however, is the verbs &amp;#x2013; they all sound a bit the same. There are some English loanwords, such as &amp;#x2018;bread&amp;#x2019; and &amp;#x2018;money&amp;#x2019;. Others are descriptive: &amp;#x2018;read&amp;#x2019; translates as &amp;#x2018;playing with words&amp;#x2019; and &amp;#x2018;drum&amp;#x2019; as &amp;#x2018;vibrating leather&amp;#x2019;. Then there are words for modern things &amp;#x2013; for &amp;#x2018;telephone&amp;#x2019;, you have to say &amp;#x2018;speak from afar&amp;#x2019;, and &amp;#x2018;car&amp;#x2019; is &amp;#x2018;go on four wheels&amp;#x2019;. I speak the language well now. Cristina&amp;#x2019;s husband spoke Selk&amp;#x2019;nam and apparently I sound just like him.
Because music is something that reaches lots of people, I started composing traditional songs in Selk&amp;#x2019;nam and formed a band with two friends. This meant that they had to learn some words, too. (6) <question-record><question></question><answer><text>E</text><feedback></feedback><correct>1</correct></answer><clue></clue></question-record> I need to teach my language to more people because if something happened to me, it would die out all over again.
</gap-fill>
</data>

<hotpot-config-file>
<jcloze>
<exercise-subtitle></exercise-subtitle>
<instructions></instructions>
<guesses-correct>Correct! Well done.</guesses-correct>
<guesses-incorrect>Some of your answers are incorrect. Incorrect answers have been left in place for you to change.</guesses-incorrect>
<next-correct-letter>The next correct letter has been added to the answer.</next-correct-letter>
<include-hint>1</include-hint>
<case-sensitive>0</case-sensitive>
<include-word-list>0</include-word-list>
<use-drop-down-list>0</use-drop-down-list>
<minimum-gap-size>6</minimum-gap-size>
<next-ex-url>nextpage.htm</next-ex-url>
<send-email>0</send-email>
<include-clues>0</include-clues>
<include-keypad>0</include-keypad>
<separate-javascript-file>0</separate-javascript-file>
</jcloze>

<global>

<times-up>Your time is over!</times-up>
<check-caption>Check</check-caption>
<ok-caption>OK</ok-caption>
<hint-caption>Hint</hint-caption>
<clue-caption>[?]</clue-caption>
<process-for-rtl>0</process-for-rtl>
<include-scorm-12>0</include-scorm-12>
<your-score-is>Your score is </your-score-is>
<keypad-characters></keypad-characters>
<next-ex-caption>=&amp;#x003E;</next-ex-caption>
<back-caption>&amp;#x003C;=</back-caption>
<contents-caption>Index</contents-caption>
<include-next-ex>0</include-next-ex>
<include-contents>0</include-contents>
<include-back>0</include-back>
<contents-url>contents.htm</contents-url>
<contents-url>contents.htm</contents-url>
<graphic-url></graphic-url>
<font-face>Geneva,Arial,sans-serif</font-face>
<font-size>medium</font-size>
<page-bg-color>#C0C0C0</page-bg-color>
<title-color>#000000</title-color>
<ex-bg-color>#FFFFFF</ex-bg-color>
<text-color>#000000</text-color>
<link-color>#0000FF</link-color>
<vlink-color>#0000CC</vlink-color>
<nav-bar-color>#000000</nav-bar-color>
<formmail-url>http://yourserver.com/cgi-bin/FormMail.pl</formmail-url>
<email>you@yourserver.com</email>
<name-please>Please enter your name:</name-please>
<user-string-1>one</user-string-1>
<user-string-2>two</user-string-2>
<user-string-3>three</user-string-3>
<header-code></header-code>
</global>
</hotpot-config-file>
</hotpot-jcloze-file>
